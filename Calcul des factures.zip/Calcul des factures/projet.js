function Calcul_Electricity() {
	var form = window.document.calc_1;

//GESTION DU CALCUL D'EAU

	var Ni = Number(form.Ni.value); //Ancien index
	var Ai = Number(form.Ai.value);//Nouvel index

	if(Ni<0 || Ai<0){
		if (Ni<0) {
			alert("Valeur invalide du nouvel index");
		}
		if (Ai<0) {
			alert("Valeur invalide de l'ancien index");
		}
	}
	else{


	var sky_1 = 30; // 30 kw free
	var tax_1 = 200; // 200 fcfa / kW after sky

	variation_index = Ni - Ai ;

	variation_index = Math.abs(variation_index);

	conso_1 = variation_index - sky_1; // consommation payante( taxed consomation)
	// sky depend of eau(water) & courant(electricity)

	if (conso_1 <= 0 ){

		result_1 = 0 ;

	}
	else{

		result_1 = conso_1*tax_1; //payant dès un certain seuil/ You buy after a ceil

	}

	console.log("Consommation d'electricité: "+result_1);

	form.elec.value = result_1;
	}

}

//GESTION DE LA FACTURE D'EAU
function Calcul_Water() {

	var form_2 = window.document.calc_2;


	var init  = Number(form_2.init.value); //Ancien index
	var final = Number(form_2.final.value);//Nouvel index

	if(init<0 || final<0){
		if (init<0) {
			alert("Valeur invalide du nouvel index");
		}
		if (final<0) {
			alert("Valeur invalide de l'ancien index");
		}
	}
	else{

	var sky_2 = 5; // 5 mètre cube d'eau gratuit
	var tax_2 = 400; // 400 fcfa / mètre cube after sky

	variation_index_2 = init - final ;

	variation_index_2 = Math.abs(variation_index_2);

	conso_2 = variation_index_2 - sky_2; // consommation payante( taxed consomation)
	// sky depend of eau(water) & courant(electricity)

	if (conso_2 <= 0 ){

		result_2 = 0;

	}
	else{

		result_2 = conso_2*tax_2; //payant dès un certain seuil/ You buy after a ceil

	}

	form_2.eau.value = result_2;
	
	console.log("Consommation d'eau: "+result_2);
}

	
}
	
const container 	= document.querySelector(".container"),
	  elect 		= document.querySelector(".elect"),
	  water 		= document.querySelector(".water"),
	  presentation  = document.querySelector(".presentation"),
	  trans_1       = document.querySelector(".trans_1"),
	  trans_2       = document.querySelector(".trans_2");	  



trans_1.addEventListener("click", ()=>{
	container.classList.add("active");
});
trans_2.addEventListener("click", ( )=>{
	container.classList.remove("active");
});

